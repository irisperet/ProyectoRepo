package com.example.sqlite2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import com.example.sqlite2.entidades.Adaptador;
import com.example.sqlite2.entidades.Prenda;

import java.util.ArrayList;
import java.util.List;

public class Main2Activity extends AppCompatActivity {

    ListView listaPrendas;
    ArrayList<Prenda> Lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        listaPrendas = (ListView) findViewById(R.id.lstDatos);

        Lista = new ArrayList<>();

        Intent elIntent = getIntent();
        Bundle datos = elIntent.getExtras();
        String ocasion = datos.getString ("PARAMETRO01");
        String temporada = datos.getString ("PARAMETRO02");
        String tipo = datos.getString ("PARAMETRO03");
        Integer imagen = datos.getInt ("PARAMETRO04");

        Lista.add(new Prenda(0,ocasion,temporada,tipo,imagen));

        Adaptador miAdaptador = new Adaptador(getApplicationContext(), Lista);

        listaPrendas.setAdapter(miAdaptador);

    }
}
