package com.example.sqlite2;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.media.Image;
import android.net.Uri;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterViewAnimator;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.sqlite2.entidades.Prenda;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static final int GALLERY_REQUEST_CODE = 1 ;
    Button btnEnviar;
    ImageView imgMostrar;
    Button btnFoto;

    ArrayList<String> ocasiones;
    ArrayAdapter<String> adaptadorOcasion;
    Spinner spnOcasion;

    ArrayList<String> temporadas;
    ArrayAdapter<String> adaptadorTemporada;
    Spinner spnTemporada;

    ArrayList<String> tipos;
    ArrayAdapter<String> adaptadorTipo;
    Spinner spnTipo;

    Prenda prenda;

    int imagen = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActionBar actionBar = getSupportActionBar(); ((ActionBar) actionBar).hide();
        ocasiones = new ArrayList<>();
        ocasiones.add("Escuela");
        ocasiones.add("Trabajo");
        ocasiones.add("Fiesta");
        ocasiones.add("Boliche");
        adaptadorOcasion = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, ocasiones);
        adaptadorOcasion.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);

        temporadas = new ArrayList<>();
        temporadas.add("Verano");
        temporadas.add("Otoño");
        temporadas.add("Invierno");
        temporadas.add("Primavera");
        adaptadorTemporada = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, temporadas);
        adaptadorTemporada.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);

        tipos = new ArrayList<>();
        tipos.add("Remera");
        tipos.add("Buzo");
        tipos.add("Pantalon");
        tipos.add("Campera");
        adaptadorTipo = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, tipos);
        adaptadorTipo.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);


        obtenerReferencias();
        setearListeners();


    }

    public void obtenerReferencias(){
        btnEnviar = (Button) findViewById(R.id.btnEnviar);
        spnOcasion = (Spinner) findViewById(R.id.cmbOcasion);
        spnOcasion.setAdapter(adaptadorOcasion);
        spnTemporada = (Spinner) findViewById(R.id.cmbTemporada);
        spnTemporada.setAdapter(adaptadorTemporada);
        spnTipo = (Spinner) findViewById(R.id.cmbTipo);
        spnTipo.setAdapter(adaptadorTipo);
        imgMostrar = (ImageView) findViewById(R.id.imgMostrar);
        btnFoto = (Button) findViewById(R.id.btnFoto);
    }

    public void setearListeners(){
        btnEnviar.setOnClickListener(btnEnviar_Click);
        btnFoto.setOnClickListener(btnFoto_Click);
    }

        View.OnClickListener btnEnviar_Click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            int iOcasionSeleccionada = spnOcasion.getSelectedItemPosition();
            String strOcasionSeleccionada = spnOcasion.getItemAtPosition(iOcasionSeleccionada).toString();
            int iTemporadaSeleccionada = spnTemporada.getSelectedItemPosition();
            String strTemporadaSeleccionada = spnTemporada.getItemAtPosition(iTemporadaSeleccionada).toString();
            int iTipoSeleccionado = spnTipo.getSelectedItemPosition();
            String strTipoSeleccionado = spnTipo.getItemAtPosition(iTipoSeleccionado).toString();
            validacion(strOcasionSeleccionada, strTemporadaSeleccionada, strTipoSeleccionado);
        }
    };

        View.OnClickListener btnFoto_Click = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            pickFromGallery();
        }
    };


    public void insertarPrenda(String strOcasion, String strTemporada, String strTipo){
        MyOpenHelper dbHelper = new MyOpenHelper(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        if (db != null) {
            // Insert con execSQL
            //db.execSQL("INSERT INTO comments (user, comment) VALUES ('Digital Learning','Esto es un comentario insertado usando el método execSQL()')");

            // Insert con ContentValues (esto claramente lo tengo que personalizar)
            ContentValues cv = new ContentValues();
            cv.put("ocasion",strOcasion);
            cv.put("temporada", strTemporada);
            cv.put("tipo", strTipo);
            db.insert("PRENDAS", null, cv);
            Toast msg = Toast.makeText(getApplicationContext(), "Se registro correctamente", Toast.LENGTH_LONG);
            msg.show();
        }
    }

    public void validacion(String strOcasion, String strTemporada, String strTipo){
        if((strOcasion.equals("")) || (strTemporada.equals("")) || (strTipo.equals("")) ){
            Toast msg = Toast.makeText(getApplicationContext(), "Por favor, completa todos los campos", Toast.LENGTH_LONG);
            msg.show();
        }
        else {
            prenda = new Prenda(0, strOcasion, strTemporada, strTipo, imagen);
            insertarPrenda(strOcasion, strTemporada, strTipo);
            probarListView(0, strOcasion, strTemporada, strTipo,imagen);
        }
    }


    private void pickFromGallery(){ //DESPLIEGA LAS OPCIONES PARA ELEGIR UNA IMAGEN DE LA GALERIA
        //Create an Intent with action as ACTION_PICK
        Intent intent=new Intent(Intent.ACTION_PICK);
        // ASEGURA QUE SOLO SE GUARDEN IMAGENES
        intent.setType("image/*");
        // EL ARRAY SE USA PARA ASEGURAR QUE SOLO SE PUEDAN SUBIR IMAGENES DE ESTOS TIPOS
        String[] mimeTypes = {"image/jpeg", "image/png"};
        intent.putExtra(Intent.EXTRA_MIME_TYPES,mimeTypes);
        startActivityForResult(intent,GALLERY_REQUEST_CODE);
    }

    public void onActivityResult(int requestCode,int resultCode,Intent data){
        // el result code es RESULT_OK solo si el usuario selecciona una imagen
        if (resultCode == MainActivity.RESULT_OK) {
            switch (requestCode){
                case GALLERY_REQUEST_CODE:
                    //data.getData devuelve el contenido URI para la imagen seleccionada
                    Uri selectedImage = data.getData();
                    imgMostrar.setImageURI(selectedImage); //ESTO SETEA LA IMAGEN EN EL XML
                    break;
            }
        }
    }

    public static final String PARAMETRO1 = "com.example.sqlite2.PARAMETRO01";
    public static final String PARAMETRO2 = "com.example.sqlite2.PARAMETRO2";
    public static final String PARAMETRO3 = "com.example.sqlite2.PARAMETRO3";
    public static final String PARAMETRO04 = "com.example.sqlite2.PARAMETRO4";

    public void probarListView(int id, String strOcasion, String strTemporada, String strTipo, int imagen){
        Log.d("Prueba", "IUPIII");
        Intent nuevaActivity = new Intent(this, Main2Activity.class);
        Bundle datos = new Bundle();
        datos.putString(MainActivity.PARAMETRO1, strOcasion);
        datos.putString(MainActivity.PARAMETRO2, strTemporada);
        datos.putString(MainActivity.PARAMETRO3, strTipo);
        datos.putInt(MainActivity.PARAMETRO04,imagen);
        nuevaActivity.putExtras(datos);
        startActivity(nuevaActivity);
    }



}
