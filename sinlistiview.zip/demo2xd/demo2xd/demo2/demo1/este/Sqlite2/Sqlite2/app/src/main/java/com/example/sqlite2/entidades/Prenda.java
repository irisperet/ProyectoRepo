package com.example.sqlite2.entidades;

public class Prenda {
    int id;
    String ocasion;
    String temporada;
    String tipo;
    int imagen;

    public int getImagen() {
        return imagen;
    }

    public void setImagen(int imagen) {
        this.imagen = imagen;
    }




    public Prenda(int _id, String _ocasion, String _temporada, String _tipo, int _imagen) {
        id = _id;
        ocasion = _ocasion;
        temporada = _temporada;
        tipo = _tipo;
        imagen = _imagen;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getOcasion() {
        return ocasion;
    }

    public void setOcasion(String ocasion) {
        this.ocasion = ocasion;
    }

    public String getTemporada() {
        return temporada;
    }

    public void setTemporada(String temporada) {
        this.temporada = temporada;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}