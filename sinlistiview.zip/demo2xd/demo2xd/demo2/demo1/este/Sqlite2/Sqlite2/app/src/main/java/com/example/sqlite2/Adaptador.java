package com.example.sqlite2;

import android.content.Context;
import android.media.Image;
import android.print.PrintDocumentAdapter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.sqlite2.R;
import com.example.sqlite2.entidades.Prenda;

import java.util.List;

public class Adaptador extends BaseAdapter {


    Context contexto;

    public Adaptador(Context contexto, List<Prenda> listaPrendas) {
        this.contexto = contexto;
        ListaPrendas = listaPrendas;
    }

    List<Prenda> ListaPrendas;


    @Override
    public int getCount(){
        return ListaPrendas.size(); //retorna la cantidad de elementos de la lista
    }

    @Override
    public Object getItem(int position){
        return ListaPrendas.get(position); //retorna el objeto de la lista que esta en la posicion "position"
    }

    @Override
    public long getItemId(int position){
        return 0;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup viewParent){
        Log.d("Prueba", "Llega al adaptador");
        View vista = convertView;
        LayoutInflater inflador = LayoutInflater.from(contexto);
        vista = inflador.inflate(R.layout.listview,null);

        //ImageView image = (ImageView) vista.findViewById(R.id.imgPrenda);
        TextView txtTipo = (TextView) vista.findViewById(R.id.txtTipo);
        TextView txtTemporada = (TextView) vista.findViewById(R.id.txtTemporada);
        TextView txtOcasion = (TextView) vista.findViewById(R.id.txtOcasion);

        txtTipo.setText(ListaPrendas.get(position).getTipo().toString());
        txtTemporada.setText(ListaPrendas.get(position).getTemporada().toString());
        txtOcasion.setText(ListaPrendas.get(position).getOcasion().toString());
        //image.setImageResource(ListaPrendas.get(position).getImagen());

        return vista;


}




}
