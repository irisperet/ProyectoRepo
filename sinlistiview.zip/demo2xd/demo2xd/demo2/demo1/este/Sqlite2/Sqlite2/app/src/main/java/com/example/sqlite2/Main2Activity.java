package com.example.sqlite2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import com.example.sqlite2.entidades.Prenda;

import java.util.ArrayList;

public class Main2Activity extends AppCompatActivity {

    ListView listaPrendas;
    ArrayList<Prenda> Lista;
    Prenda prenda;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Log.d("Prueba", "Hasta la activity 2 llega");
        prenda = MainActivity.traerRegistros();

        listaPrendas = (ListView) findViewById(R.id.lstDatos);

        Log.d("Prueba", "El problema no es lstDatos");

        Lista = new ArrayList<>();

        Intent elIntent = getIntent();
        Bundle datos = elIntent.getExtras();
        String ocasion = datos.getString ("PARAMETRO01");
        /*String temporada = datos.getString ("PARAMETRO02");
        String tipo = datos.getString ("PARAMETRO03");
        Integer imagen = datos.getInt ("PARAMETRO04");
        */
        Log.d("Prueba", "Llegan todos los parametros");
        Lista.add(prenda);
        Log.d("Prueba", "Se llena la lista?");
        Adaptador miAdaptador = new Adaptador(getApplicationContext(), Lista);

        listaPrendas.setAdapter(miAdaptador);

    }
}
